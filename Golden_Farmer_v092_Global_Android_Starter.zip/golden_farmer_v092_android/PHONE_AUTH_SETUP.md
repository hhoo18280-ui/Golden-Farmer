# Real Phone Authentication (Production plan)

The prototype OTP is not real verification. For production: use Firebase Authentication Phone Sign-in or a secure backend integrated with an SMS provider. Never store OTPs or passwords in localStorage. Enforce OTP rate limits, abuse prevention, account recovery, consent, phone normalization (E.164), server-side verification, and privacy/data deletion. Country codes are only a UI selection; they do not establish user location or eligibility.
