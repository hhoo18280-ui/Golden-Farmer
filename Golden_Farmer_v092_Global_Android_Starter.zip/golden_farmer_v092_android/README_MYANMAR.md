# Golden Farmer v0.9.2 — Global Phone Edition

- Phone sign-in UI with international country calling codes.
- Myanmar/English language switch.
- Guest mode.
- OTP demo: code is 123456; no SMS is sent and no real phone verification occurs.
- This is a frontend prototype; real auth needs secure backend + SMS provider.

To install PWA: host on HTTPS, open in Chrome, use Install app / Add to Home Screen.
For Play Store: build Android with Capacitor, review target SDK, signing, Data Safety, privacy policy, testing.
