# Release Checklist

- [ ] Replace demo OTP with real server-side phone authentication
- [ ] Phone number formatting and country code validation (E.164)
- [ ] OTP throttling, abuse controls, recovery
- [ ] Audit bilingual strings; translate every screen
- [ ] Database migrations, sync, conflict resolution, backup restore tests
- [ ] Accessibility, offline, low-end device and Android version testing
- [ ] Secure storage, permissions and data deletion
- [ ] Privacy policy and Google Play Data Safety declarations
- [ ] Generate signed Android App Bundle (AAB)
- [ ] Internal/closed testing, crashes, ANR and performance review
- [ ] Store assets, screenshots, listing, support email, content rating
- [ ] Verify target API and Play policy requirements before submission
