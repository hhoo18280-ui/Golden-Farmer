# Privacy Policy Draft — Golden Farmer

The current prototype stores farm records locally on the device. Phone number entry and OTP are demonstration-only and do not send SMS or verify ownership. No production account backend is currently configured. Before production release, publish an accurate policy covering the backend/SMS provider, collected data, purpose, retention, deletion, security, sharing, contact and jurisdiction.
