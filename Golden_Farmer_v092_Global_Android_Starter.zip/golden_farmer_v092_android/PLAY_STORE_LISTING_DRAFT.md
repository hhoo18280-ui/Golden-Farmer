# Google Play Listing Draft

**App name:** Golden Farmer
**Short description:** Farm, crop, livestock and business management for farmers.
**Full description:** Golden Farmer helps farmers manage crop fields, farming tasks, expenses and income, livestock records, crop knowledge, market notes and field observations. Available in Myanmar and English.

Do not publish this draft until features, privacy/data safety disclosures, screenshots, support contact, age/content ratings and Google Play policy requirements are reviewed.
