# Backend setup notes

The SQL migration is a reviewed-design draft, not yet validated against a live Supabase project. Apply it to a disposable development project first. Verify function ownership and grants, RLS behavior, indexes, migration rollback, and backup restore. Configure auth providers and storage buckets separately. Do not enable public writes to market observations; ingest through a trusted server function after source validation.
