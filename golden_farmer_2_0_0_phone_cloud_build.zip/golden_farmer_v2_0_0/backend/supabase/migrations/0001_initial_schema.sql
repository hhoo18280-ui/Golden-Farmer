-- Golden Farmer initial schema (PostgreSQL / Supabase)
-- Apply only in a disposable development project first. Review with a database engineer.
begin;
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  preferred_language text not null default 'my' check (preferred_language ~ '^[a-z]{2}(-[A-Z]{2})?$'),
  country_code text,
  preferred_currency char(3) not null default 'MMK',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.farms (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(trim(name)) between 1 and 120),
  country_code char(2),
  region text,
  locality text,
  area_value numeric(14,3) check (area_value is null or area_value >= 0),
  area_unit text not null default 'acre' check (area_unit in ('acre','hectare','sqm')),
  timezone text not null default 'UTC',
  owner_id uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.farm_members (
  farm_id uuid not null references public.farms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','manager','worker','viewer')),
  created_at timestamptz not null default now(),
  primary key (farm_id,user_id)
);

create table if not exists public.plots (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  name text not null,
  area_value numeric(14,3) check (area_value is null or area_value >= 0),
  area_unit text not null default 'acre' check (area_unit in ('acre','hectare','sqm')),
  soil_type text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.crop_cycles (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  plot_id uuid references public.plots(id) on delete set null,
  crop_code text not null,
  variety text,
  season_label text,
  planted_on date,
  expected_harvest_on date,
  harvested_on date,
  area_value numeric(14,3) check (area_value is null or area_value >= 0),
  area_unit text not null default 'acre' check (area_unit in ('acre','hectare','sqm')),
  status text not null default 'planned' check (status in ('planned','active','harvested','cancelled')),
  notes text,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (expected_harvest_on is null or planted_on is null or expected_harvest_on >= planted_on)
);

create table if not exists public.livestock_groups (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  species_code text not null,
  breed text,
  group_name text not null,
  head_count integer not null default 0 check (head_count >= 0),
  acquired_on date,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.farm_tasks (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  title text not null check (length(trim(title)) between 1 and 180),
  details text,
  due_at timestamptz,
  status text not null default 'open' check (status in ('open','in_progress','done','cancelled')),
  assigned_to uuid references auth.users(id) on delete set null,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ledger_entries (
  id uuid primary key default gen_random_uuid(),
  farm_id uuid not null references public.farms(id) on delete cascade,
  entry_type text not null check (entry_type in ('income','expense')),
  category text not null,
  amount numeric(18,2) not null check (amount > 0),
  currency char(3) not null,
  occurred_on date not null default current_date,
  note text,
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.market_observations (
  id uuid primary key default gen_random_uuid(),
  country_code char(2) not null,
  region text,
  market_name text not null,
  commodity_code text not null,
  unit text not null,
  price numeric(18,4) not null check (price >= 0),
  currency char(3) not null,
  observed_at timestamptz not null,
  source_name text not null,
  verification_status text not null default 'unverified' check (verification_status in ('unverified','community_reported','verified')),
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists farms_owner_idx on public.farms(owner_id);
create index if not exists farm_members_user_idx on public.farm_members(user_id);
create index if not exists plots_farm_idx on public.plots(farm_id);
create index if not exists crop_cycles_farm_status_idx on public.crop_cycles(farm_id,status);
create index if not exists livestock_groups_farm_idx on public.livestock_groups(farm_id);
create index if not exists farm_tasks_farm_due_idx on public.farm_tasks(farm_id,due_at);
create index if not exists ledger_farm_date_idx on public.ledger_entries(farm_id,occurred_on desc);
create index if not exists market_lookup_idx on public.market_observations(country_code,commodity_code,observed_at desc);

-- SECURITY DEFINER helper avoids recursive RLS evaluation on farm_members.
create or replace function public.is_farm_member(target_farm uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.farm_members fm
    where fm.farm_id = target_farm and fm.user_id = (select auth.uid())
  ) or exists (
    select 1 from public.farms f
    where f.id = target_farm and f.owner_id = (select auth.uid())
  );
$$;

create or replace function public.is_farm_owner(target_farm uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.farms f where f.id = target_farm and f.owner_id = (select auth.uid()));
$$;

create or replace function public.has_farm_role(target_farm uuid, allowed_roles text[])
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.farm_members fm
    where fm.farm_id = target_farm and fm.user_id = (select auth.uid()) and fm.role = any(allowed_roles)
  ) or exists (
    select 1 from public.farms f
    where f.id = target_farm and f.owner_id = (select auth.uid())
  );
$$;

revoke all on function public.is_farm_member(uuid) from public;
revoke all on function public.is_farm_owner(uuid) from public;
revoke all on function public.has_farm_role(uuid,text[]) from public;
grant execute on function public.is_farm_member(uuid) to authenticated;
grant execute on function public.is_farm_owner(uuid) to authenticated;
grant execute on function public.has_farm_role(uuid,text[]) to authenticated;

alter table public.profiles enable row level security;
alter table public.farms enable row level security;
alter table public.farm_members enable row level security;
alter table public.plots enable row level security;
alter table public.crop_cycles enable row level security;
alter table public.livestock_groups enable row level security;
alter table public.farm_tasks enable row level security;
alter table public.ledger_entries enable row level security;
alter table public.market_observations enable row level security;

create policy "profile_select_self" on public.profiles for select to authenticated using (id = (select auth.uid()));
create policy "profile_insert_self" on public.profiles for insert to authenticated with check (id = (select auth.uid()));
create policy "profile_update_self" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));

create policy "farm_select_members" on public.farms for select to authenticated using (owner_id = (select auth.uid()) or public.is_farm_member(id));
create policy "farm_insert_owner" on public.farms for insert to authenticated with check (owner_id = (select auth.uid()));
create policy "farm_update_manager" on public.farms for update to authenticated using (public.has_farm_role(id,array['owner','manager'])) with check (public.has_farm_role(id,array['owner','manager']));
create policy "farm_delete_owner" on public.farms for delete to authenticated using (owner_id = (select auth.uid()));

create policy "membership_select_related" on public.farm_members for select to authenticated using (user_id = (select auth.uid()) or public.has_farm_role(farm_id,array['owner','manager']));
create policy "membership_insert_owner_only" on public.farm_members for insert to authenticated with check (public.is_farm_owner(farm_id) and role in ('manager','worker','viewer'));
create policy "membership_update_owner_only" on public.farm_members for update to authenticated using (public.is_farm_owner(farm_id)) with check (public.is_farm_owner(farm_id) and role in ('manager','worker','viewer'));
create policy "membership_delete_owner_only" on public.farm_members for delete to authenticated using (public.is_farm_owner(farm_id));

create policy "plots_select_member" on public.plots for select to authenticated using (public.is_farm_member(farm_id));
create policy "plots_write_manager" on public.plots for all to authenticated using (public.has_farm_role(farm_id,array['owner','manager'])) with check (public.has_farm_role(farm_id,array['owner','manager']));
create policy "cycles_select_member" on public.crop_cycles for select to authenticated using (public.is_farm_member(farm_id));
create policy "cycles_write_manager" on public.crop_cycles for all to authenticated using (public.has_farm_role(farm_id,array['owner','manager'])) with check (public.has_farm_role(farm_id,array['owner','manager']));
create policy "livestock_select_member" on public.livestock_groups for select to authenticated using (public.is_farm_member(farm_id));
create policy "livestock_write_manager" on public.livestock_groups for all to authenticated using (public.has_farm_role(farm_id,array['owner','manager'])) with check (public.has_farm_role(farm_id,array['owner','manager']));
create policy "tasks_select_member" on public.farm_tasks for select to authenticated using (public.is_farm_member(farm_id));
create policy "tasks_write_manager" on public.farm_tasks for all to authenticated using (public.has_farm_role(farm_id,array['owner','manager'])) with check (public.has_farm_role(farm_id,array['owner','manager']));
create policy "ledger_select_member" on public.ledger_entries for select to authenticated using (public.is_farm_member(farm_id));
create policy "ledger_write_manager" on public.ledger_entries for all to authenticated using (public.has_farm_role(farm_id,array['owner','manager'])) with check (public.has_farm_role(farm_id,array['owner','manager']));

-- Public market reads are limited to published observations; client writes are blocked.
create policy "market_read_published" on public.market_observations for select to anon,authenticated using (verification_status in ('community_reported','verified'));

commit;
