# Golden Farmer 2.0.0 — Phone-only Cloud Build

This project can be built without installing Flutter or Android Studio on the phone. GitHub Actions runs the Android build on a hosted Linux runner.

## What this workflow does

1. Creates the missing Android Gradle project scaffold using Flutter.
2. Resolves the Flutter dependencies.
3. Runs `flutter analyze`.
4. Builds a release APK for device testing.
5. Builds an Android App Bundle (AAB) for Play Console upload.
6. Publishes both outputs as a downloadable GitHub Actions artifact.

## Required before a build can run

- A GitHub account.
- The source files committed to a GitHub repository on the `main` branch.
- GitHub Actions enabled for that repository.

## Phone-only steps

1. Open GitHub in Chrome and sign in.
2. Create a **private** repository named `golden-farmer`.
3. Upload the contents of this project folder (not the ZIP file itself), keeping the `.github/workflows/android-build.yml` path intact, then commit to `main`.
4. Open the repository's **Actions** tab. Select **Golden Farmer Android Build** and tap **Run workflow** if it has not started automatically.
5. Wait for the run to finish. If it succeeds, open that run and download the artifact named `golden-farmer-2.0.0-android`.
6. Extract the artifact ZIP. Install `app-release.apk` on the Android phone. Android may ask permission to install apps from that browser or file manager.

## Important release notes

- A successful CI build is not the same as a tested release. Install and test the APK before wider use.
- The AAB produced by this initial workflow is not yet signed with a dedicated Play upload key. Do not upload it to production Play Console until a permanent application ID, upload keystore, privacy policy, Data safety declarations, screenshots, and Play Console account requirements are completed.
- Do not commit keystore files, passwords, API secrets, Supabase service-role keys, or private credentials to this repository.
- This app currently uses on-device local storage. It does not yet provide live OTP login, cloud synchronization, AI photo diagnosis, live market feeds, or weather services.

## Current Android application ID

Flutter generates the Android project with organization `com.goldenfarmer` and project name `golden_farmer`. Confirm the resulting application ID in `android/app/build.gradle` before publishing. Changing it after publication creates a different app identity.
