# Golden Farmer 2.0.0 — Release Candidate Source

## Version identity
- App version: `2.0.0`
- Android version code: `200`
- Package: `golden_farmer`

## Included in this candidate
- Carried forward the existing Flutter farmer app: Burmese/English interface, dashboard, farm records, livestock notes, crop symptom checklist, market notebook, crop library, fertilizer/IPM safety guidance, and farm accounting.
- Carries the production foundation documentation, draft Supabase schema, API contract, privacy/security notes, and acceptance-test plan from v0.10.0.
- Updates the in-app profile version label and package version to 2.0.0.

## Important release status
This is a **2.0.0 source release candidate**, not a compiled Android installer. The source was not compiled or tested in this environment because Flutter and the Android SDK are unavailable. No APK or AAB is included. No live cloud service, phone OTP, cloud backup, AI image diagnosis, or Play Store publication is active.

## Before installation or Play Store submission
1. Generate the Android platform folder using `flutter create --platforms=android .` with a supported Flutter SDK.
2. Run `flutter pub get`, `flutter analyze`, and device tests; resolve all errors.
3. Set a permanent reverse-domain Android application ID and app icons.
4. Configure a private upload keystore and protect its passwords. Never commit signing credentials.
5. Build an APK for device testing and an AAB for Play Console.
6. Complete privacy policy, Data safety, content rating, target API, screenshots, and Play testing requirements.

Do not distribute this source package as though it were an installable APK.
