# Acceptance Test Plan

## Identity and tenant isolation
- User A cannot read, update, delete, or enumerate User B's farms, plots, crop cycles, livestock, tasks, or ledger entries.
- Viewer can read but cannot mutate; worker cannot change farm ownership or membership; manager can manage operational records; only owner can delete the farm.
- OTP resend, wrong code, expired code, repeated attempts, SIM change, and country-code edge cases are rate-limited and produce clear errors.

## Offline and data integrity
- Create farm, crop cycle, task, animal group, and ledger entry in airplane mode; reconnect; verify exactly-once synchronization.
- Force a timeout during sync; retry; verify no duplicate ledger entry.
- Edit same entity on two devices; verify documented conflict behavior and user-visible status.
- Change device language/timezone; stored data and farm-local dates remain correct.

## Agronomy and safety
- Crop advice identifies region/crop/stage assumptions and distinguishes general information from verified local label advice.
- Unknown symptoms return uncertainty and request additional observations rather than a definitive diagnosis.
- Chemical guidance never fabricates rates; displays label, local registration, PPE, PHI/REI requirements when verified data exists.

## Android quality
- Fresh install, upgrade from prior version, app restart, process death, denied permissions, no network, slow network, large text, screen reader, and low-storage tests.
- Verify app icon, splash, package ID, version code, signing, backup behavior, deep links, and crash-free startup.
