# Golden Farmer — Production Architecture

## Product boundary
Golden Farmer is a multi-country farm operations platform. A farmer may manage multiple farms, plots, crop cycles, livestock groups, work tasks, and financial ledgers. Country, language, currency, measurement unit, and timezone are explicit data—not assumptions based on device locale.

## System layers
1. **Android client:** Flutter, feature-first modules, accessible responsive UI, local cache, encrypted sensitive local data, offline write queue.
2. **Identity:** managed authentication with verified phone OTP and optional federated sign-in. Phone number is normalized to E.164; country calling code is selected explicitly. Never treat a client-side demo OTP as authentication.
3. **Data:** PostgreSQL with tenant isolation through farm membership and Row Level Security. All records carry farm scope; membership roles are owner, manager, worker, viewer.
4. **Files:** private object storage for farm images and diagnostic photos; signed, short-lived URLs; retention and deletion workflow.
5. **Server functions:** privileged actions, AI orchestration, SMS provider integration, price ingestion, notifications, and moderation. Secrets stay server-side.
6. **Observability:** crash reporting, structured server logs with personal data redacted, metrics, alerting, backup verification, and incident runbooks.

## Offline-first synchronization
- Every local mutation receives a UUID and client-generated `updated_at` plus a monotonically increasing local revision.
- Queue operations while offline; retry with exponential backoff and jitter.
- Use idempotency keys for create/payment-like actions.
- Server is authoritative for permissions and canonical timestamps.
- Conflict policy is entity-specific: append-only ledger entries are never silently overwritten; farm profile edits use optimistic concurrency; tasks may use last-write-wins only with visible conflict history.
- Surface sync state (pending, synced, conflict, failed) to the user.

## AI crop diagnosis guardrails
Photo diagnosis is decision support, not a definitive laboratory diagnosis. Ask for crop, variety, location, growth stage, symptoms, recent weather, and pesticide/fertilizer history. Return ranked possibilities, confidence/uncertainty, safe next observations, and escalation advice. Never recommend a pesticide product or dose without checking local registration, label, crop, target pest, pre-harvest interval, and protective equipment requirements. Keep human agronomist review for high-risk cases.

## Localization and units
Store canonical numeric quantities with explicit units. Do not convert currencies without a dated FX source. Store market quote source, market, commodity grade, unit, currency, observation time, and verification status. Keep timestamps in UTC and render using the farm timezone.
