# Phone-only build status

A GitHub Actions workflow is included at `.github/workflows/android-build.yml`. It is configured to build both APK and AAB on GitHub-hosted Linux when source is pushed to `main` or the workflow is manually run.

This package itself is source code. No APK/AAB is included because the cloud workflow has not yet been run against a connected GitHub repository. The build result must be checked in GitHub Actions before claiming a successful build.
