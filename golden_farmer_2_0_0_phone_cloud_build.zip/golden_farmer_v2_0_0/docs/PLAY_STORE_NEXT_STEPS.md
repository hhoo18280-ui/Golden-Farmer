# Google Play — Submission Preparation

1. Choose a permanent unique Android application ID (for example, `com.yourcompany.goldenfarmer`) before first publication.
2. Create and protect the Play App Signing upload key; keep backups offline and never commit it.
3. Generate a signed Android App Bundle (`.aab`) with a monotonically increasing version code.
4. Test internal and closed tracks on real devices; resolve crashes, ANRs, permission problems, and policy issues.
5. Host a complete privacy policy and provide an account deletion URL if users can create accounts.
6. Complete Data safety, app access instructions, content rating, target audience, ads, permissions, and store listing truthfully.
7. Upload to Play Console and follow the current testing/review requirements for the developer account.

This package contains no signing key, no AAB, and no Play Console submission.
