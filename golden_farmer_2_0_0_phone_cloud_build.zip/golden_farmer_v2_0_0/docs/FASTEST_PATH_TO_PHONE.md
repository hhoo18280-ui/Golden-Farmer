# Fastest path to test Golden Farmer on an Android phone

1. Extract this ZIP on a computer with Flutter SDK and Android SDK installed.
2. Run the commands in the project README.
3. Resolve analyzer/build errors before installing.
4. Build `flutter build apk --release` and install the resulting APK on a test phone.
5. Keep the app in internal/closed testing until data handling, privacy disclosures, permissions, and device compatibility are verified.

This environment currently has Java but does not have Flutter, Dart, Gradle, or Android SDK tooling. Therefore no genuine APK/AAB can be produced or verified here. A fabricated or empty APK would not install and would waste the user's time.
