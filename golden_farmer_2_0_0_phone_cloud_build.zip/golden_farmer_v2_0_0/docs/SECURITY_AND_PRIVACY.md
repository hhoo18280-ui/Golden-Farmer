# Security and Privacy Controls

## Non-negotiable controls
- Enforce Row Level Security on every user-owned table; test with two unrelated users and a farm member with each role.
- Never ship service-role keys, database credentials, SMS credentials, AI keys, or signing keys in the mobile binary or repository.
- Use TLS, short-lived access tokens, refresh-token rotation where supported, secure device storage, and server-side authorization.
- Validate all inputs on the server; apply rate limits to OTP, uploads, search, and AI endpoints.
- Private image storage by default; restrict file size/type, scan uploads, use expiring signed URLs, and define retention/deletion.
- Provide account deletion and data export workflows; deletion must cover database rows, photos, backups according to a documented retention policy, and third-party processors where applicable.
- Collect only data needed for the feature; explain location/photo access before requesting permissions.
- Maintain incident response, access review, dependency updates, and backup restore drills.

## Google Play disclosures
Complete Data safety, app access, content rating, target API, permissions, privacy policy, account deletion URL (if account creation is supported), and ads declarations based on the actual shipped SDKs and data flows. Do not copy a generic declaration. Re-check Play Console policy at submission time.

## Data classification
- Public: published crop knowledge and verified market summaries.
- Internal: farm names, crop schedules, livestock counts, tasks, and ledger entries.
- Sensitive: phone number, precise farm coordinates, diagnostic photos, account identifiers.

Precise farm location and diagnostic photos must not be public by default.
