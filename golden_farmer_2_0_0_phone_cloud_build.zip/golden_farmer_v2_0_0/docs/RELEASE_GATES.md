# Production Release Gates — Must Pass Before Public Launch

| Gate | Required evidence | Status in this package |
|---|---|---|
| Android build | Reproducible signed AAB and build log | Not run; Flutter SDK unavailable |
| Device QA | Android 8+ / current Android, low-memory and small-screen checks | Not run |
| Auth | Real international OTP, abuse controls, account recovery | Not implemented |
| Backend | Migration applied in staging; RLS tests pass | SQL draft only |
| Sync | Offline queue, retry, conflict resolution, migration | Not implemented |
| Privacy | Hosted policy, deletion/export, accurate Data safety form | Template only |
| AI | Server-side model, evaluation set, uncertainty, expert review | Not implemented |
| Market data | Licensed/traceable sources and timestamped observations | Manual local notes only |
| Security | Secret scan, dependency scan, penetration review, backup restore | Not run |
| Play Console | Store listing, screenshots, app access, closed test, policy review | Not submitted |

A release is blocked if any mandatory gate remains open. A source ZIP is not evidence of Play Store readiness.
