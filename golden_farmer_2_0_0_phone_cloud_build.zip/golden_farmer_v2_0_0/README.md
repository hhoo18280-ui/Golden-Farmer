# Golden Farmer 2.0.0 — Release Candidate Source

Golden Farmer is a Flutter-based agriculture and livestock companion. This package advances the prior v0.10.0 foundation package to the `2.0.0+200` version identity and carries forward the current working prototype and production-planning materials.

## What is included
- `lib/main.dart` — Flutter application source.
- `pubspec.yaml` — package dependencies and version `2.0.0+200`.
- `backend/` — draft Supabase/PostgreSQL schema and API contract; not connected to a live backend.
- `docs/` — architecture, security/privacy, release gates and Play Store next steps.
- `qa/` — acceptance-test plan.
- `CHANGELOG_2.0.0.md` — release scope and status.

## Current app functions
- Burmese / English language toggle.
- Farm records and livestock notes stored locally on the device.
- Crop symptom checklist / crop doctor reference flow.
- Market price notebook.
- Offline crop knowledge library.
- Fertilizer, IPM and pesticide safety reference.
- Farm income and expense tracking.

## Critical limitations
**This is source code, not an APK or AAB.** It has not been compiled or device-tested in this environment because Flutter and the Android SDK are not installed here. It is not published on Google Play. The app currently stores records locally using `SharedPreferences`; there is no active phone OTP, cloud sync, live AI diagnosis, weather feed, satellite/GIS service, or marketplace backend. The Supabase SQL is a draft and has not been applied to a live project.

## Build on a computer with Flutter and Android SDK
```bash
flutter create --platforms=android .
flutter pub get
flutter analyze
flutter test
flutter build apk --release
flutter build appbundle --release
```

The commands are build instructions, not proof that a build has passed. Use a permanent application ID, app icon, privacy policy, Play Data safety declarations, and a protected upload key before Play Store submission. Never put service-role keys or signing secrets in the app source.
